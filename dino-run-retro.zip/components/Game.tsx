import React, { useEffect, useRef, useState, useCallback } from 'react';
import { 
  CANVAS_HEIGHT, 
  CANVAS_WIDTH, 
  GAME_CONFIG, 
  DINO_HEIGHT, 
  DINO_WIDTH, 
  DINO_X_POS,
  COLOR_DINO,
  COLOR_ROBOT,
  COLOR_ALIEN,
  COLOR_OBSTACLE,
  COLOR_GROUND,
  COLOR_COIN,
  COLOR_SHIELD,
  CACTUS_VARIANTS
} from '../constants';
import { GameStatus, DinoState, Obstacle, CharacterType, Item, ItemType } from '../types';
import { playJumpSound, playGameOverSound, playScoreSound, playItemSound, playLevelUpSound } from '../utils/sound';

const Game: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [status, setStatus] = useState<GameStatus>(GameStatus.IDLE);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [showLevelUp, setShowLevelUp] = useState(false);
  
  // Character Selection State
  const [characterType, setCharacterType] = useState<CharacterType>('DINO');

  // Use refs for mutable game state to avoid closure staleness in the loop
  const gameState = useRef({
    frameId: 0,
    scoreFloat: 0, // Float score for smooth increment
    gameSpeed: GAME_CONFIG.baseSpeed,
    dino: {
      y: GAME_CONFIG.groundHeight - DINO_HEIGHT,
      vy: 0,
      isJumping: false,
      isDucking: false,
      frame: 0,
      invincibleUntil: 0
    } as DinoState,
    obstacles: [] as Obstacle[],
    items: [] as Item[],
    lastObstacleTime: 0
  });

  // Load High Score
  useEffect(() => {
    const saved = localStorage.getItem('dino-highscore');
    if (saved) setHighScore(parseInt(saved, 10));
  }, []);

  // --- Drawing Logic ---

  const drawCharacter = (ctx: CanvasRenderingContext2D, dino: DinoState, type: CharacterType) => {
    const x = DINO_X_POS;
    const y = dino.y;
    
    // Invincibility Effect (Glow)
    if (Date.now() < dino.invincibleUntil) {
      ctx.globalAlpha = 0.5 + 0.5 * Math.sin(Date.now() / 50); // Blink
      ctx.strokeStyle = COLOR_SHIELD;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(x + 20, y + 15, 35, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1.0;
    }

    // Set Color based on Character
    if (type === 'ROBOT') ctx.fillStyle = COLOR_ROBOT;
    else if (type === 'ALIEN') ctx.fillStyle = COLOR_ALIEN;
    else ctx.fillStyle = COLOR_DINO;

    if (type === 'DINO') {
      // Classic Dino Body
      ctx.fillRect(x + 10, y, 20, 30);
      ctx.fillRect(x + 20, y - 10, 20, 15); // Head
      ctx.fillStyle = '#fff';
      ctx.fillRect(x + 28, y - 8, 4, 4); // Eye
      ctx.fillStyle = COLOR_DINO;
      ctx.fillRect(x, y + 10, 10, 5); // Tail
    } else if (type === 'ROBOT') {
      // Robot Body (Boxier)
      ctx.fillRect(x + 5, y, 30, 30); // Body
      ctx.fillRect(x + 10, y - 12, 20, 12); // Head
      ctx.fillStyle = '#ef4444'; // Red Eye
      ctx.fillRect(x + 15, y - 8, 10, 4); 
      // Antenna
      ctx.fillStyle = '#9ca3af';
      ctx.fillRect(x + 18, y - 18, 4, 6);
      ctx.fillStyle = COLOR_ROBOT;
    } else if (type === 'ALIEN') {
      // Alien Body (Slimmer)
      ctx.fillRect(x + 12, y + 5, 16, 25);
      // Big Head
      ctx.fillRect(x + 8, y - 15, 24, 20);
      // Eyes
      ctx.fillStyle = '#000';
      ctx.fillRect(x + 12, y - 10, 4, 4);
      ctx.fillRect(x + 24, y - 10, 4, 4);
      ctx.fillStyle = COLOR_ALIEN;
    }
    
    // Legs (Shared Animation Logic)
    ctx.fillStyle = (type === 'ROBOT' ? COLOR_ROBOT : (type === 'ALIEN' ? COLOR_ALIEN : COLOR_DINO));
    const legOffset = Math.floor(dino.frame / 5) % 2 === 0 ? 0 : 5;
    
    if (dino.isJumping) {
      ctx.fillRect(x + 12, y + 30, 6, 8);
      ctx.fillRect(x + 22, y + 30, 6, 8);
    } else {
      if (legOffset === 0) {
        ctx.fillRect(x + 12, y + 30, 6, 17); 
        ctx.fillRect(x + 22, y + 30, 6, 8);  
      } else {
        ctx.fillRect(x + 12, y + 30, 6, 8);  
        ctx.fillRect(x + 22, y + 30, 6, 17); 
      }
    }
  };

  const drawObstacles = (ctx: CanvasRenderingContext2D, obstacles: Obstacle[]) => {
    ctx.fillStyle = COLOR_OBSTACLE;
    obstacles.forEach(obs => {
        // Main stem
        ctx.fillRect(obs.x + obs.width/3, obs.y, obs.width/3, obs.height);
        // Arms
        ctx.fillRect(obs.x, obs.y + obs.height * 0.3, obs.width/3, obs.height * 0.1);
        ctx.fillRect(obs.x, obs.y + obs.height * 0.15, obs.width/6, obs.height * 0.2);
        ctx.fillRect(obs.x + (obs.width/3)*2, obs.y + obs.height * 0.4, obs.width/3, obs.height * 0.1);
        ctx.fillRect(obs.x + obs.width - (obs.width/6), obs.y + obs.height * 0.2, obs.width/6, obs.height * 0.2);
    });
  };

  const drawItems = (ctx: CanvasRenderingContext2D, items: Item[]) => {
    items.forEach(item => {
      if (item.type === 'COIN') {
        ctx.fillStyle = COLOR_COIN;
        ctx.beginPath();
        ctx.arc(item.x + item.width/2, item.y + item.height/2, item.width/2, 0, Math.PI * 2);
        ctx.fill();
        // Inner detail
        ctx.fillStyle = '#FFF';
        ctx.font = '10px "Press Start 2P"';
        ctx.fillText("$", item.x + 8, item.y + 16);
      } else if (item.type === 'SHIELD') {
        ctx.fillStyle = COLOR_SHIELD;
        // Shield shape (simple rect for pixel look)
        ctx.fillRect(item.x, item.y, item.width, item.height);
        ctx.fillStyle = '#FFF';
        ctx.fillRect(item.x + 8, item.y + 5, 8, 14); // Cross vertical
        ctx.fillRect(item.x + 5, item.y + 8, 14, 8); // Cross horizontal
      }
    });
  };

  const drawGround = (ctx: CanvasRenderingContext2D) => {
    ctx.beginPath();
    ctx.moveTo(0, GAME_CONFIG.groundHeight);
    ctx.lineTo(CANVAS_WIDTH, GAME_CONFIG.groundHeight);
    ctx.strokeStyle = COLOR_GROUND;
    ctx.lineWidth = 2;
    ctx.stroke();
  };

  // --- Game Loop ---

  const resetGame = useCallback(() => {
    gameState.current = {
      frameId: 0,
      scoreFloat: 0,
      gameSpeed: GAME_CONFIG.baseSpeed,
      dino: {
        y: GAME_CONFIG.groundHeight - DINO_HEIGHT,
        vy: 0,
        isJumping: false,
        isDucking: false,
        frame: 0,
        invincibleUntil: 0
      },
      obstacles: [],
      items: [],
      lastObstacleTime: 0
    };
    setScore(0);
    setLevel(1);
    setShowLevelUp(false);
    setStatus(GameStatus.PLAYING);
    playJumpSound();
  }, []);

  const jump = useCallback(() => {
    const { dino } = gameState.current;
    if (!dino.isJumping && status === GameStatus.PLAYING) {
      dino.vy = GAME_CONFIG.jumpForce;
      dino.isJumping = true;
      playJumpSound();
    }
  }, [status]);

  const update = useCallback(() => {
    if (status !== GameStatus.PLAYING) return;

    const state = gameState.current;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    
    if (!canvas || !ctx) return;

    // 1. Physics - Dino
    state.dino.y += state.dino.vy;
    state.dino.vy += GAME_CONFIG.gravity;

    const groundY = GAME_CONFIG.groundHeight - DINO_HEIGHT;
    if (state.dino.y >= groundY) {
      state.dino.y = groundY;
      state.dino.vy = 0;
      state.dino.isJumping = false;
    }

    state.dino.frame++;

    // 2. Spawning Logic
    const minSpawnGap = 60 + (state.gameSpeed * 10);
    const timeSinceLast = state.frameId - state.lastObstacleTime;
    
    // Spawn Obstacles
    if (timeSinceLast > minSpawnGap && Math.random() < 0.02) {
      const variant = CACTUS_VARIANTS[Math.floor(Math.random() * CACTUS_VARIANTS.length)];
      state.obstacles.push({
        id: Date.now(),
        x: CANVAS_WIDTH,
        y: GAME_CONFIG.groundHeight - variant.height,
        width: variant.width,
        height: variant.height,
        type: variant.type
      });
      state.lastObstacleTime = state.frameId;
    }

    // Spawn Items (Lower chance, avoid overlapping obstacle logic simply by chance for now)
    if (timeSinceLast > 30 && timeSinceLast < minSpawnGap - 30 && Math.random() < 0.005) {
      const isCoin = Math.random() > 0.3; // 70% Coin, 30% Shield
      const itemY = isCoin ? GAME_CONFIG.groundHeight - 80 : GAME_CONFIG.groundHeight - 40; // Coin in air, Shield lower
      state.items.push({
        id: Date.now() + 1,
        x: CANVAS_WIDTH,
        y: itemY,
        width: 24,
        height: 24,
        type: isCoin ? 'COIN' : 'SHIELD'
      });
    }

    // 3. Movement & Cleanup
    state.obstacles.forEach(obs => obs.x -= state.gameSpeed);
    state.items.forEach(item => item.x -= state.gameSpeed);

    state.obstacles = state.obstacles.filter(obs => obs.x + obs.width > 0);
    state.items = state.items.filter(item => item.x + item.width > 0);

    // 4. Collision Detection
    const dinoHitbox = {
      x: DINO_X_POS + 10,
      y: state.dino.y + 5,
      w: DINO_WIDTH - 20,
      h: DINO_HEIGHT - 10
    };

    // Item Collision
    for (let i = state.items.length - 1; i >= 0; i--) {
      const item = state.items[i];
      if (
         dinoHitbox.x < item.x + item.width &&
         dinoHitbox.x + dinoHitbox.w > item.x &&
         dinoHitbox.y < item.y + item.height &&
         dinoHitbox.y + dinoHitbox.h > item.y
      ) {
        // Collected
        playItemSound();
        if (item.type === 'COIN') {
          state.scoreFloat += 50;
        } else if (item.type === 'SHIELD') {
          state.dino.invincibleUntil = Date.now() + 5000; // 5 seconds
        }
        state.items.splice(i, 1);
      }
    }

    // Obstacle Collision
    const isInvincible = Date.now() < state.dino.invincibleUntil;
    if (!isInvincible) {
      for (const obs of state.obstacles) {
         const obsHitbox = {
           x: obs.x + 5,
           y: obs.y + 5,
           w: obs.width - 10,
           h: obs.height - 10
         };

         if (
           dinoHitbox.x < obsHitbox.x + obsHitbox.w &&
           dinoHitbox.x + dinoHitbox.w > obsHitbox.x &&
           dinoHitbox.y < obsHitbox.y + obsHitbox.h &&
           dinoHitbox.y + dinoHitbox.h > obsHitbox.y
         ) {
           setStatus(GameStatus.GAME_OVER);
           playGameOverSound();
           if (score > highScore) {
             setHighScore(Math.floor(score));
             localStorage.setItem('dino-highscore', Math.floor(score).toString());
           }
           return; 
         }
      }
    }

    // 5. Scoring & Level Logic
    state.scoreFloat += 0.1;
    const currentScoreInt = Math.floor(state.scoreFloat);
    
    // Level Up every 500 points
    const calculatedLevel = Math.floor(currentScoreInt / 500) + 1;
    if (calculatedLevel > level) {
      setLevel(calculatedLevel);
      playLevelUpSound();
      setShowLevelUp(true);
      setTimeout(() => setShowLevelUp(false), 2000);
      // Speed bump on level up
      state.gameSpeed += 0.5; 
    }

    if (currentScoreInt > 0 && currentScoreInt % 100 === 0 && Math.floor(state.scoreFloat - 0.1) !== currentScoreInt) {
        playScoreSound();
    }

    setScore(currentScoreInt);
    state.gameSpeed += GAME_CONFIG.speedMultiplier;

    // 6. Draw
    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    drawGround(ctx);
    drawItems(ctx, state.items);
    drawCharacter(ctx, state.dino, characterType);
    drawObstacles(ctx, state.obstacles);

    state.frameId = requestAnimationFrame(update);
  }, [status, score, highScore, level, characterType]);

  // Loop trigger
  useEffect(() => {
    if (status === GameStatus.PLAYING) {
      gameState.current.frameId = requestAnimationFrame(update);
    }
    return () => cancelAnimationFrame(gameState.current.frameId);
  }, [status, update]);

  // Initial Draw for Idle State
  useEffect(() => {
    if (status === GameStatus.IDLE) {
      const ctx = canvasRef.current?.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        drawGround(ctx);
        drawCharacter(ctx, {
            y: GAME_CONFIG.groundHeight - DINO_HEIGHT,
            vy: 0,
            isJumping: false,
            isDucking: false,
            frame: 0,
            invincibleUntil: 0
        }, characterType);
        
        ctx.fillStyle = '#535353';
        ctx.font = '20px "Press Start 2P"';
        ctx.textAlign = 'center';
        ctx.fillText("SELECT CHARACTER & PRESS SPACE", CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 40);
      }
    }
  }, [status, characterType]);

  // Inputs
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.code === 'Space' || e.code === 'ArrowUp')) {
        e.preventDefault();
        if (status === GameStatus.IDLE || status === GameStatus.GAME_OVER) {
          resetGame();
        } else {
          jump();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [status, jump, resetGame]);

  return (
    <div className="relative group cursor-pointer select-none" onClick={() => status === GameStatus.PLAYING ? jump() : null}>
      <canvas
        ref={canvasRef}
        width={CANVAS_WIDTH}
        height={CANVAS_HEIGHT}
        className="w-full h-auto bg-white block"
      />
      
      {/* HUD */}
      <div className="absolute top-4 right-4 flex gap-4 text-gray-600 font-bold text-xs md:text-sm">
        <span>LV {level}</span>
        <span>HI {highScore.toString().padStart(5, '0')}</span>
        <span>{score.toString().padStart(5, '0')}</span>
      </div>

      {/* Invincibility Indicator */}
      {status === GameStatus.PLAYING && Date.now() < gameState.current.dino.invincibleUntil && (
        <div className="absolute top-14 right-4 text-blue-500 font-bold text-xs animate-pulse">
           SHIELD ACTIVE
        </div>
      )}

      {/* Level Up Overlay */}
      {showLevelUp && (
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 text-2xl md:text-4xl text-yellow-500 font-bold animate-bounce drop-shadow-md">
          LEVEL UP!
        </div>
      )}

      {/* Character Selection Overlay (IDLE) */}
      {status === GameStatus.IDLE && (
        <div className="absolute bottom-20 left-0 w-full flex justify-center gap-4">
           <button 
             onClick={(e) => { e.stopPropagation(); setCharacterType('DINO'); }}
             className={`p-3 border-2 rounded ${characterType === 'DINO' ? 'bg-gray-200 border-gray-600' : 'bg-white border-transparent'}`}
           >
             🦖 DINO
           </button>
           <button 
             onClick={(e) => { e.stopPropagation(); setCharacterType('ROBOT'); }}
             className={`p-3 border-2 rounded ${characterType === 'ROBOT' ? 'bg-blue-100 border-blue-600 text-blue-600' : 'bg-white border-transparent'}`}
           >
             🤖 ROBOT
           </button>
           <button 
             onClick={(e) => { e.stopPropagation(); setCharacterType('ALIEN'); }}
             className={`p-3 border-2 rounded ${characterType === 'ALIEN' ? 'bg-green-100 border-green-600 text-green-600' : 'bg-white border-transparent'}`}
           >
             👽 ALIEN
           </button>
        </div>
      )}

      {/* Game Over Overlay */}
      {status === GameStatus.GAME_OVER && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/5 backdrop-blur-[1px]">
          <div className="text-2xl text-gray-700 mb-4">GAME OVER</div>
          <button 
            onClick={(e) => { e.stopPropagation(); resetGame(); }}
            className="p-2 px-4 bg-gray-700 text-white rounded hover:bg-gray-800 transition-colors"
          >
            ↺ RESTART
          </button>
        </div>
      )}
    </div>
  );
};

export default Game;